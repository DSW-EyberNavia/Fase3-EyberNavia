using System;
using Microsoft.VisualBasic;
using System.Diagnostics.Eventing.Reader;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

namespace BoleraRobles
{
    public partial class BoleraR : Form
    {
       
        
        Stack<PilaBolos> MyPilaBolos = new Stack<PilaBolos>();
        public BoleraR()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {


            PilaBolos myPilaBolos = new PilaBolos();
            myPilaBolos.Nombre = tbNombre.Text;
            myPilaBolos.Idjugador = tbIdjugador.Text;
            myPilaBolos.Direcci�n = tbdireccion.Text;
            myPilaBolos.Fecha = dateTimePicker1.Text;
            myPilaBolos.Totalreserva = tbtotal.Text;
            MyPilaBolos.Push(myPilaBolos);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = MyPilaBolos.ToArray();

            if (cB1.Checked == true)
            {
                myPilaBolos.Pista = cB1.Text;
            }
            if (cB2.Checked == true)
            {
                myPilaBolos.Pista = cB2.Text;
            }
            if (cB3.Checked == true)
            {
                myPilaBolos.Pista = cB3.Text;
            }

            if (cB4.Checked == true)
            {
                myPilaBolos.Pista = cB4.Text;
            }
            //dataGridView1.Rows.Add("1",cB1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int Op = 0;
            int total = 0;
            int total1 = 0;
            int vp = 0;
            int vj = 0;
            int R = 0;
            double Des = 0;
            int des = 0;

            if (cbr.Checked == true)
            {
                R = R + 50000;
                tbtotal.Text = R.ToString();
            }

            // Pistas y valores adicionales en la reserva

            if (cB1.Checked == true)
            {
                Op = Op + 0;
                total = R + Op;
                tbtotal.Text = total.ToString();
            }
            else
            {
                if (cB2.Checked == true)
                {
                    Op = Op + 0;
                    total = R + Op;
                    tbtotal.Text = total.ToString();
                }
                else
                {
                    if (cB3.Checked == true)
                    {
                        Op = Op + 5000;
                        total = R + Op;
                        tbtotal.Text = total.ToString();
                    }
                    else
                    {
                        if (cB4.Checked == true)
                        {
                            Op = Op + 10000;
                            total = R + Op;
                            tbtotal.Text = total.ToString();
                        }
                    }

                }




            }
            // Valor adicional de Jugadores
            if (checkBox3.Checked == true)
            {
                vj = vj + 0;
                total = R + Op;
                total1 = total + vj;
                tbtotal.Text = total1.ToString();
            }
            else
            {
                if (cBaj2.Checked == true)
                {
                    vj = vj + 1000;
                    total = R + Op;
                    total1 = R + vj + Op;
                    tbtotal.Text = total1.ToString();
                }
                else
                {
                    if (cBaj3.Checked == true)
                    {
                        vj = vj + 2000;
                        total = R + Op;
                        total1 = R + vj + Op;
                        tbtotal.Text = total1.ToString();
                    }
                    else
                    {
                        if (cBaj4.Checked == true)
                        {
                            vj = vj + 3000;
                            total = R + Op;
                            total1 = R + vj + Op;
                            tbtotal.Text = total1.ToString();
                        }
                        else
                        {
                            if (cBaj5.Checked == true)
                            {
                                vj = vj + 4000;
                                total = R + Op;
                                total1 = R + vj + Op;
                                tbtotal.Text = total1.ToString();
                            }
                            else
                            {
                                if (cBaj6.Checked == true)
                                {
                                    vj = vj + 5000;
                                    total = R + Op;
                                    total1 = R + vj + Op;
                                    tbtotal.Text = total1.ToString();


                                }

                            }
                        }
                    }

                }

            }
            if (checkBox1.Checked == true)
            {
                Des = Math.Round(total1 * 0.10);
                des = (int)(total1 - Des);
                tbtotal.Text = des.ToString();
                MessageBox.Show(" Eres beneficiario para el descuento del 10% en tu reserva ");
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {

           


        }

        private void Sumr_Click(object sender, EventArgs e)
        {
             decimal reporte = 0;

                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            // llamamos a la columna 
                            reporte = Convert.ToDecimal(row.Cells["Totalreserva"].Value);
                        }
                        tbreporte.Text = Convert.ToString(reporte);
        }
    }



}
