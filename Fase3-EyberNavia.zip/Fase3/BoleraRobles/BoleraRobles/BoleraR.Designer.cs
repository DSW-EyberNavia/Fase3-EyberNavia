﻿namespace BoleraRobles
{
    partial class BoleraR
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BoleraR));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            tbNombre = new TextBox();
            tbIdjugador = new TextBox();
            tbdireccion = new TextBox();
            button1 = new Button();
            button3 = new Button();
            dateTimePicker1 = new DateTimePicker();
            label7 = new Label();
            label10 = new Label();
            label12 = new Label();
            tbtotal = new TextBox();
            label5 = new Label();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            gbpista = new GroupBox();
            cB4 = new CheckBox();
            cB1 = new CheckBox();
            cB3 = new CheckBox();
            cB2 = new CheckBox();
            dataGridView1 = new DataGridView();
            JValorAdicional = new GroupBox();
            cBaj6 = new CheckBox();
            cBaj5 = new CheckBox();
            cBaj4 = new CheckBox();
            cBaj3 = new CheckBox();
            cBaj2 = new CheckBox();
            checkBox3 = new CheckBox();
            button2 = new Button();
            cbr = new CheckBox();
            label8 = new Label();
            tbreporte = new TextBox();
            Sumr = new Button();
            label11 = new Label();
            gbpista.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            JValorAdicional.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Image = (Image)resources.GetObject("label1.Image");
            label1.ImageAlign = ContentAlignment.TopLeft;
            label1.Location = new Point(240, 26);
            label1.Name = "label1";
            label1.Size = new Size(125, 15);
            label1.TabIndex = 0;
            label1.Text = "FORMULARIO DE PILA";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Image = (Image)resources.GetObject("label2.Image");
            label2.ImageAlign = ContentAlignment.TopLeft;
            label2.Location = new Point(61, 80);
            label2.Name = "label2";
            label2.Size = new Size(105, 15);
            label2.TabIndex = 1;
            label2.Text = "Nombre completo";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.ControlLightLight;
            label3.Image = (Image)resources.GetObject("label3.Image");
            label3.ImageAlign = ContentAlignment.TopLeft;
            label3.Location = new Point(44, 125);
            label3.Name = "label3";
            label3.Size = new Size(142, 15);
            label3.TabIndex = 2;
            label3.Text = "Número de identificación";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = SystemColors.ControlLightLight;
            label4.Image = (Image)resources.GetObject("label4.Image");
            label4.ImageAlign = ContentAlignment.TopLeft;
            label4.Location = new Point(84, 166);
            label4.Name = "label4";
            label4.Size = new Size(57, 15);
            label4.TabIndex = 3;
            label4.Text = "Dirección";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = SystemColors.ControlLightLight;
            label6.Image = (Image)resources.GetObject("label6.Image");
            label6.ImageAlign = ContentAlignment.TopLeft;
            label6.Location = new Point(44, 232);
            label6.Name = "label6";
            label6.Size = new Size(107, 15);
            label6.TabIndex = 5;
            label6.Text = "Número de la pista";
            // 
            // tbNombre
            // 
            tbNombre.Location = new Point(206, 80);
            tbNombre.Name = "tbNombre";
            tbNombre.Size = new Size(202, 23);
            tbNombre.TabIndex = 6;
            // 
            // tbIdjugador
            // 
            tbIdjugador.Location = new Point(206, 122);
            tbIdjugador.Name = "tbIdjugador";
            tbIdjugador.Size = new Size(202, 23);
            tbIdjugador.TabIndex = 7;
            // 
            // tbdireccion
            // 
            tbdireccion.Location = new Point(206, 166);
            tbdireccion.Name = "tbdireccion";
            tbdireccion.Size = new Size(202, 23);
            tbdireccion.TabIndex = 8;
            // 
            // button1
            // 
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.TopLeft;
            button1.Location = new Point(117, 468);
            button1.Name = "button1";
            button1.Size = new Size(75, 24);
            button1.TabIndex = 12;
            button1.Text = "REGISTRAR";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.ForeColor = SystemColors.ControlLightLight;
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.TopLeft;
            button3.Location = new Point(400, 468);
            button3.Name = "button3";
            button3.Size = new Size(102, 24);
            button3.TabIndex = 14;
            button3.Text = "TOTAL RESERVA";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(348, 264);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(171, 23);
            dateTimePicker1.TabIndex = 16;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = SystemColors.ControlLightLight;
            label7.Image = (Image)resources.GetObject("label7.Image");
            label7.ImageAlign = ContentAlignment.TopLeft;
            label7.Location = new Point(44, 343);
            label7.Name = "label7";
            label7.Size = new Size(122, 15);
            label7.TabIndex = 17;
            label7.Text = "Número de jugadores";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = SystemColors.ControlLightLight;
            label10.Image = (Image)resources.GetObject("label10.Image");
            label10.ImageAlign = ContentAlignment.TopLeft;
            label10.Location = new Point(12, 9);
            label10.Name = "label10";
            label10.Size = new Size(76, 15);
            label10.TabIndex = 23;
            label10.Text = "Valor Reserva";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = SystemColors.ControlLightLight;
            label12.Image = (Image)resources.GetObject("label12.Image");
            label12.ImageAlign = ContentAlignment.TopLeft;
            label12.Location = new Point(359, 377);
            label12.Name = "label12";
            label12.Size = new Size(160, 30);
            label12.TabIndex = 25;
            label12.Text = "      Se encuentra afiliado \r\na una caja de compensación.\r\n";
            // 
            // tbtotal
            // 
            tbtotal.AccessibleRole = AccessibleRole.None;
            tbtotal.Enabled = false;
            tbtotal.Location = new Point(238, 529);
            tbtotal.Name = "tbtotal";
            tbtotal.Size = new Size(111, 23);
            tbtotal.TabIndex = 27;
            tbtotal.TabStop = false;
            tbtotal.TextAlign = HorizontalAlignment.Center;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = SystemColors.ControlLightLight;
            label5.Image = (Image)resources.GetObject("label5.Image");
            label5.ImageAlign = ContentAlignment.TopLeft;
            label5.Location = new Point(255, 510);
            label5.Name = "label5";
            label5.Size = new Size(74, 15);
            label5.TabIndex = 28;
            label5.Text = "Total a Pagar";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = SystemColors.ActiveCaptionText;
            checkBox1.BackgroundImage = (Image)resources.GetObject("checkBox1.BackgroundImage");
            checkBox1.ForeColor = SystemColors.ControlLightLight;
            checkBox1.Location = new Point(397, 416);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(35, 19);
            checkBox1.TabIndex = 29;
            checkBox1.Text = "Si";
            checkBox1.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackgroundImage = (Image)resources.GetObject("checkBox2.BackgroundImage");
            checkBox2.ForeColor = SystemColors.ControlLightLight;
            checkBox2.Location = new Point(438, 416);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(42, 19);
            checkBox2.TabIndex = 30;
            checkBox2.Text = "No";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // gbpista
            // 
            gbpista.BackColor = SystemColors.ActiveCaptionText;
            gbpista.BackgroundImage = (Image)resources.GetObject("gbpista.BackgroundImage");
            gbpista.Controls.Add(cB4);
            gbpista.Controls.Add(cB1);
            gbpista.Controls.Add(cB3);
            gbpista.Controls.Add(cB2);
            gbpista.ForeColor = SystemColors.ControlLightLight;
            gbpista.Location = new Point(44, 252);
            gbpista.Name = "gbpista";
            gbpista.Size = new Size(272, 41);
            gbpista.TabIndex = 32;
            gbpista.TabStop = false;
            gbpista.Text = "Pistas y Valor adicional";
            // 
            // cB4
            // 
            cB4.AutoSize = true;
            cB4.Location = new Point(190, 17);
            cB4.Name = "cB4";
            cB4.Size = new Size(77, 19);
            cB4.TabIndex = 4;
            cB4.Text = "4. $ 10000";
            cB4.UseVisualStyleBackColor = true;
            // 
            // cB1
            // 
            cB1.AutoSize = true;
            cB1.Location = new Point(8, 17);
            cB1.Name = "cB1";
            cB1.Size = new Size(53, 19);
            cB1.TabIndex = 3;
            cB1.Text = "1. $ 0";
            cB1.UseVisualStyleBackColor = true;
            // 
            // cB3
            // 
            cB3.AutoSize = true;
            cB3.ForeColor = SystemColors.ControlLightLight;
            cB3.Location = new Point(125, 17);
            cB3.Name = "cB3";
            cB3.Size = new Size(68, 19);
            cB3.TabIndex = 2;
            cB3.Text = "3.$ 5000";
            cB3.UseVisualStyleBackColor = true;
            // 
            // cB2
            // 
            cB2.AutoSize = true;
            cB2.ForeColor = SystemColors.ControlLightLight;
            cB2.Location = new Point(65, 17);
            cB2.Name = "cB2";
            cB2.Size = new Size(53, 19);
            cB2.TabIndex = 1;
            cB2.Text = "2. $ 0";
            cB2.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(4, 618);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(563, 127);
            dataGridView1.TabIndex = 35;
            // 
            // JValorAdicional
            // 
            JValorAdicional.BackColor = SystemColors.ActiveCaptionText;
            JValorAdicional.Controls.Add(cBaj6);
            JValorAdicional.Controls.Add(cBaj5);
            JValorAdicional.Controls.Add(cBaj4);
            JValorAdicional.Controls.Add(cBaj3);
            JValorAdicional.Controls.Add(cBaj2);
            JValorAdicional.Controls.Add(checkBox3);
            JValorAdicional.ForeColor = SystemColors.ControlLightLight;
            JValorAdicional.Location = new Point(44, 361);
            JValorAdicional.Name = "JValorAdicional";
            JValorAdicional.Size = new Size(271, 65);
            JValorAdicional.TabIndex = 36;
            JValorAdicional.TabStop = false;
            JValorAdicional.Text = "V Adicional";
            // 
            // cBaj6
            // 
            cBaj6.AutoSize = true;
            cBaj6.Location = new Point(173, 43);
            cBaj6.Name = "cBaj6";
            cBaj6.Size = new Size(71, 19);
            cBaj6.TabIndex = 5;
            cBaj6.Text = "6. $ 5000";
            cBaj6.UseVisualStyleBackColor = true;
            // 
            // cBaj5
            // 
            cBaj5.AutoSize = true;
            cBaj5.Location = new Point(99, 43);
            cBaj5.Name = "cBaj5";
            cBaj5.Size = new Size(68, 19);
            cBaj5.TabIndex = 4;
            cBaj5.Text = "5.$ 4000";
            cBaj5.UseVisualStyleBackColor = true;
            // 
            // cBaj4
            // 
            cBaj4.AutoSize = true;
            cBaj4.Location = new Point(28, 42);
            cBaj4.Name = "cBaj4";
            cBaj4.Size = new Size(68, 19);
            cBaj4.TabIndex = 3;
            cBaj4.Text = "4.$ 3000";
            cBaj4.UseVisualStyleBackColor = true;
            // 
            // cBaj3
            // 
            cBaj3.AutoSize = true;
            cBaj3.Location = new Point(173, 15);
            cBaj3.Name = "cBaj3";
            cBaj3.Size = new Size(68, 19);
            cBaj3.TabIndex = 2;
            cBaj3.Text = "3.$ 2000";
            cBaj3.UseVisualStyleBackColor = true;
            // 
            // cBaj2
            // 
            cBaj2.AutoSize = true;
            cBaj2.Location = new Point(99, 18);
            cBaj2.Name = "cBaj2";
            cBaj2.Size = new Size(68, 19);
            cBaj2.TabIndex = 1;
            cBaj2.Text = "2.$ 1000";
            cBaj2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(28, 17);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(50, 19);
            checkBox3.TabIndex = 0;
            checkBox3.Text = "1.$ 0";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveCaptionText;
            button2.ForeColor = SystemColors.ControlLightLight;
            button2.Location = new Point(254, 469);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 37;
            button2.Text = "ELIMINAR";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // cbr
            // 
            cbr.AutoSize = true;
            cbr.BackColor = SystemColors.ActiveCaptionText;
            cbr.ForeColor = SystemColors.ControlLightLight;
            cbr.Location = new Point(96, 9);
            cbr.Name = "cbr";
            cbr.Size = new Size(56, 19);
            cbr.TabIndex = 38;
            cbr.Text = "50000";
            cbr.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.ActiveCaptionText;
            label8.ForeColor = SystemColors.ControlLightLight;
            label8.Location = new Point(241, 797);
            label8.Name = "label8";
            label8.Size = new Size(69, 15);
            label8.TabIndex = 39;
            label8.Text = "Eyber Navia";
            // 
            // tbreporte
            // 
            tbreporte.Location = new Point(275, 588);
            tbreporte.Name = "tbreporte";
            tbreporte.Size = new Size(124, 23);
            tbreporte.TabIndex = 46;
            tbreporte.TextAlign = HorizontalAlignment.Center;
            // 
            // Sumr
            // 
            Sumr.BackColor = Color.Black;
            Sumr.ForeColor = SystemColors.ControlLightLight;
            Sumr.Location = new Point(195, 589);
            Sumr.Name = "Sumr";
            Sumr.Size = new Size(75, 23);
            Sumr.TabIndex = 45;
            Sumr.Text = "Reporte";
            Sumr.UseVisualStyleBackColor = false;
            Sumr.Click += Sumr_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = SystemColors.ActiveCaptionText;
            label11.ForeColor = SystemColors.ControlLightLight;
            label11.Location = new Point(202, 570);
            label11.Name = "label11";
            label11.Size = new Size(183, 15);
            label11.TabIndex = 44;
            label11.Text = "Reporte de las reservas generadas";
            // 
            // BoleraR
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(571, 749);
            Controls.Add(tbreporte);
            Controls.Add(Sumr);
            Controls.Add(label11);
            Controls.Add(label8);
            Controls.Add(cbr);
            Controls.Add(button2);
            Controls.Add(JValorAdicional);
            Controls.Add(dataGridView1);
            Controls.Add(gbpista);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Controls.Add(label5);
            Controls.Add(tbtotal);
            Controls.Add(label12);
            Controls.Add(label10);
            Controls.Add(label7);
            Controls.Add(dateTimePicker1);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(tbdireccion);
            Controls.Add(tbIdjugador);
            Controls.Add(tbNombre);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "BoleraR";
            Text = "BoleraRobles";
            Load += Form1_Load;
            gbpista.ResumeLayout(false);
            gbpista.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            JValorAdicional.ResumeLayout(false);
            JValorAdicional.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private void cBp3_CheckedChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private TextBox tbNombre;
        private TextBox tbIdjugador;
        private TextBox tbdireccion;
        private Button button1;
        private Button button3;
        private DateTimePicker dateTimePicker1;
        private Label label7;
        private Label label8;
        private Label label9;
        private CheckedListBox checkedListBox4;
        private Label label10;
        private Label label12;
        private TextBox tbtotal;
        private Label label5;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private GroupBox gbpista;
        private CheckBox cB4;
        private CheckBox cB3;
        private CheckBox cB2;
        private CheckBox cB1;
        private GroupBox gbjugadores;
        private CheckBox cBox6;
        private CheckBox cBox5;
        private CheckBox cBox4;
        private CheckBox cBox3;
        private CheckBox cBox2;
        private CheckBox cBox1;
        private GroupBox gbjugador;
        private CheckBox checkBox12;
        private CheckBox checkBox11;
        private CheckBox cBp2;
        private DataGridView dataGridView1;
        private CheckBox cBp1;
        private CheckBox cBp3;
        private CheckBox cBp4;
        private GroupBox JValorAdicional;
        private CheckBox cBaj2;
        private CheckBox checkBox3;
        private CheckBox cBaj4;
        private CheckBox cBaj3;
        private CheckBox cBaj6;
        private CheckBox cBaj5;
        private DataGridViewCellEventHandler dataGridView1_CellContentClick;
        private Button button2;
        private CheckBox cbr;
        private TextBox tbreporte;
        private Button Sumr;
        private Label label11;

        public CheckBox cbaj2 { get; private set; }
        public EventHandler gbjugador_Enter { get; private set; }
    }
}