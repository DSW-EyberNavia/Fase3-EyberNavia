﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JardínInfantil
{
    public partial class RegistroE : Form
    {
        List<ListaJardin> myljardin = new List<ListaJardin>();
        int lugar;
        public RegistroE()
        {
            InitializeComponent();
            Desactivar();
        }

        void Desactivar()
        {
            button3.Enabled = false;

        }

        private void RegistroE_Load(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {


            ListaJardin mylista = new ListaJardin();
            mylista.NúmeroRegistroCivil = tbrc.Text;
            mylista.Nombre = tbnombre.Text;
            mylista.CondiciónEspecial = comboBox1.Text;
            mylista.EstratoSocioeconomico = cbce.Text;
            mylista.Fecha = dateTimePicker1.Text;
            mylista.Terapia = dateTimePicker1.Text;
            myljardin.Add(mylista);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = myljardin;

            tbrc.Clear();
            tbnombre.Clear();

            if (radioButton1.Checked == true)
            {
                mylista.Terapia = radioButton1.Text;
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                    mylista.Terapia = radioButton2.Text;
                }
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            lugar = dataGridView1.CurrentRow.Index;
            tbnombre.Text = dataGridView1.Rows[lugar].ToString();
            tbrc.Text = dataGridView1.Rows[lugar].ToString();

            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
          



        }

        private void button3_Click(object sender, EventArgs e)
        {


            
            dataGridView1.Rows.RemoveAt(lugar); 
        } 
    }
}
