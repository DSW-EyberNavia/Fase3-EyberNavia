﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JardínInfantil
{
    internal class ListaJardin
    {

        public string Nombre { get; set; }

        public string NúmeroRegistroCivil { get; set; }

        public string CondiciónEspecial { get; set; }

        public string EstratoSocioeconomico { get; set; }


        public string Fecha { get; set; }

        public string Terapia { get; set; }



    }
}
