﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EPS 
{
    internal class ColaEPS
    {
       public string Nombre { get; set; }

        public string identificacion { get; set; }

        public string edad { get; set; }

        public string Fecha { get; set; }

        public string Consultar { get; set; }

        public string TiempoMinutos { get; set; }

    }
}
